# Utility & Redstone Gadgets
> Minecraft Bedrock Edition (1.21.0+) Add-on

Pocket workbenches, portable void trash cans, auto-feeders, and brass lanterns.

## In-Game Guide Book
- **Title**: Engineer's Blueprints
- **Author**: Chief Engineer Nikola
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§cUtility & Redstone Gadgets§r

Maximize daily efficiency with portable gadgets and mechanical aids.
**Page 2:** §l§1Inventions§r

§6Pocket Workbench§r: Inventory accessible crafting.
§8Portable Void Trash Can§r: Incinerate junk stacks.
§cAuto Nutrient Dispenser§r: Automated feeding system.
§eBrass Miner's Lantern§r: Portable torch lighting.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Engineer's Blueprints** | `ug:ug_guidebook` | 1 | Shapeless: Book + Paper |
| **Pocket Workbench** | `ug:pocket_workbench` | 1 | Pattern: ` L  / LCL /  L ` |
| **Portable Void Trash Can** | `ug:void_trash_can` | 1 | Pattern: ` I  / ICI /  L ` |
| **Auto Nutrient Dispenser** | `ug:auto_feeder` | 1 | Pattern: ` R  / DHD /  R ` |
| **Brass Miner's Lantern** | `ug:brass_lantern` | 1 | Pattern: ` C  / CTC /  C ` |
| **Clockwork Cogwheel** | `ug:redstone_gear` | 64 | Pattern: ` I  / IRI /  I ` |
