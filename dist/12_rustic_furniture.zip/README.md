# Rustic Furniture
> Minecraft Bedrock Edition (1.21.0+) Add-on

Handcrafted wooden stools, dining tables, paper lanterns, wall shelves, and crates.

## In-Game Guide Book
- **Title**: Rustic Carpenter's Manual
- **Author**: Master Carpenter Edwin
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Rustic Furniture§r

Furnish houses and cabins with cozy wooden items.
**Page 2:** §l§1Furniture Items§r

§6Rustic Wooden Stool§r: Oak slab + sticks.
§eRustic Dining Table§r: Oak planks + sticks.
§fHanging Paper Lantern§r: Paper + torch.
§6Reinforced Storage Crate§r: Planks + chest.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Rustic Carpenter's Manual** | `rf:rf_guidebook` | 1 | Shapeless: Book + Paper |
| **Rustic Wooden Stool** | `rf:wooden_stool` | 64 | Pattern: ` P  / S S / S S` |
| **Rustic Dining Table** | `rf:dining_table` | 64 | Pattern: `PPP / S S / S S` |
| **Hanging Paper Lantern** | `rf:paper_lantern` | 64 | Pattern: ` S  / PTP /  S ` |
| **Wall Display Shelf** | `rf:rustic_shelf` | 64 | Pattern: `SSS / P P /    ` |
| **Reinforced Wooden Crate** | `rf:storage_crate` | 64 | Pattern: `PIP / ICI / PIP` |
