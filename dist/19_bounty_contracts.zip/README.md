# Bounty Hunter Contracts
> Minecraft Bedrock Edition (1.21.0+) Add-on

Monster hunting scrolls, guild badges, slayer medallions, and honor tokens.

## In-Game Guide Book
- **Title**: Bounty Guild Handbook
- **Author**: Guildmaster Drake
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Bounty Hunter Guild§r

Take up contracts to cleanse hostile creatures from settlements.
**Page 2:** §l§1Guild Items§r

§4Zombie Bounty Contract§r: Rotten flesh + paper.
§2Creeper Bounty Contract§r: Gunpowder + paper.
§6Hunter's Guild Badge§r: Proof of Guild standing.
§eMonster Slayer Medallion§r: Diamond-forged trophy.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Bounty Guild Handbook** | `bh:bh_guidebook` | 1 | Shapeless: Book + Paper |
| **Zombie Bounty Contract** | `bh:bounty_scroll_zombie` | 16 | Pattern: ` R  / PPP /  F ` |
| **Creeper Bounty Contract** | `bh:bounty_scroll_creeper` | 16 | Pattern: ` G  / PPP /  F ` |
| **Hunter's Guild Badge** | `bh:hunter_badge` | 1 | Pattern: ` G  / GEG /  G ` |
| **Monster Slayer Medallion** | `bh:slayer_medallion` | 1 | Pattern: ` C  / DGD /  C ` |
| **Guild Honor Token** | `bh:hunter_token` | 64 | Pattern: ` I  /  G  /  I ` |
