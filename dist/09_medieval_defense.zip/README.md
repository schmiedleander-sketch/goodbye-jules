# Medieval Defense & Traps
> Minecraft Bedrock Edition (1.21.0+) Add-on

Iron caltrops, heavy bear traps, reinforced tower shields, and barricades.

## In-Game Guide Book
- **Title**: Fortress Master's Codex
- **Author**: Commander Valerius
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§8Medieval Defense & Traps§r

Fortify bases and defend against night raids with heavy barricades and perimeter traps.
**Page 2:** §l§1Defenses§r

§7Iron Caltrops§r: Sharp spikes hurting oncoming mobs.
§6Bear Trap§r: Spring-loaded mob trap.
§eReinforced Tower Shield§r: High deflection shield.
§4Fortified Barricade§r: Iron bar blockade.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Fortress Master's Codex** | `md:md_guidebook` | 1 | Shapeless: Book + Paper |
| **Iron Caltrops** | `md:iron_caltrops` | 64 | Pattern: ` I  / III /  I ` |
| **Heavy Bear Trap** | `md:bear_trap` | 16 | Pattern: `I I / SIS / III` |
| **Reinforced Tower Shield** | `md:tower_shield` | 1 | Pattern: `III / WPW /  W ` |
| **Sharpened Stakes** | `md:wooden_spikes` | 64 | Pattern: ` S  /  L  /  L ` |
| **Fortified Barricade** | `md:reinforced_barricade` | 16 | Pattern: `III / PPP / III` |
