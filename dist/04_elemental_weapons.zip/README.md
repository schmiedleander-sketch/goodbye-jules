# Elemental Weapons
> Minecraft Bedrock Edition (1.21.0+) Add-on

Blazing Flameblades, Glacial Frost Daggers, and Thunder Hammers.

## In-Game Guide Book
- **Title**: Armory of Elements
- **Author**: Grand Smith Thorin
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§cElemental Armory§r

Imbue weapon blades with primordial fire, frost, and storm energy.
**Page 2:** §l§1Weapons§r

§cBlazing Flameblade§r (8 Dmg): Ignites foes on impact.
§bGlacial Frost Dagger§r (6 Dmg): Swift ice strikes.
§eThunder Hammer§r (10 Dmg): Crushing lightning impact.
§aTempest Spear§r (7 Dmg): Piercing gust weapon.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Armory of Elements** | `ew:ew_guidebook` | 1 | Shapeless: Book + Paper |
| **Blazing Flameblade** | `ew:flameblade` | 1 | Pattern: ` B  /  M  /  S ` |
| **Glacial Frost Dagger** | `ew:frost_dagger` | 1 | Pattern: ` I  /  P  /  S ` |
| **Thunder Hammer** | `ew:thunder_hammer` | 1 | Pattern: `LCL /  S  /  S ` |
| **Tempest Spear** | `ew:tempest_spear` | 1 | Pattern: ` F  /  B  /  S ` |
| **Primal Elemental Core** | `ew:elemental_core` | 64 | Pattern: ` F  / IDT /  S ` |
