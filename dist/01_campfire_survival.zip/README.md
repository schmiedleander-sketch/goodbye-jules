# Campfire Survival & Foods
> Minecraft Bedrock Edition (1.21.0+) Add-on

Wilderness survival gear, canteens, hearty trail meals, skewers, and marshmallows.

## In-Game Guide Book
- **Title**: Campfire Survival Guide
- **Author**: Wilderness Ranger
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§2Campfire Survival§r

Welcome to wilderness expeditions!

Carry a §6Leather Canteen§r to stay hydrated, cook §6Marshmallows§r over a campfire, and prepare §6Hearty Campfire Stew§r for long excursions.
**Page 2:** §l§1Survival Items§r

§6Leather Canteen§r:
Crafted with leather & glass bottle. Quenches thirst and cleanses minor ailments.

§6Trail Mix§r:
Wheat seeds, sweet berries, & cocoa beans for quick sprint recovery.
**Page 3:** §l§1Campfire Meals§r

§6Roast Skewer§r:
Cooked beef & pork skewer on a wooden stick.

§6Hearty Stew§r:
Bowl filled with mushrooms, baked potatoes, and cooked beef.
**Page 4:** §l§1Field Crafting§r

All recipes use standard crafting grids. Read this guidebook anytime or craft a replacement with Book + Paper!

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Campfire Survival Guide** | `cs:cs_guidebook` | 1 | Shapeless: Book + Paper |
| **Leather Canteen** | `cs:leather_canteen` | 1 | Pattern: ` L  / LGL /  L ` |
| **Trail Mix** | `cs:trail_mix` | 64 | Pattern: `WSW / SCS / WSW` |
| **Roast Skewer** | `cs:roast_skewer` | 16 | Pattern: ` B  /  P  /  S ` |
| **Marshmallow on a Stick** | `cs:marshmallow_stick` | 16 | Pattern: ` S  /  M  /  T ` |
| **Hearty Campfire Stew** | `cs:hearty_stew` | 1 | Pattern: ` C  / BPM /  W ` |
