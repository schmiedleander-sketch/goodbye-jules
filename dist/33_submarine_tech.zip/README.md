# Submarine Technology & Deep Abyss
> Minecraft Bedrock Edition (1.21.0+) Add-on

Deep-sea ballast tanks, acoustic sonar radars, pressurized torpedoes, and abyssal suits.

## In-Game Guide Book
- **Title**: Submariner's Blueprint Manual
- **Author**: Chief Diver Cousteau
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§3Submarine Technology§r

Navigate deepest ocean ravines and crush zones with heavy pressure hulls and acoustic sonar arrays.
**Page 2:** §l§1Vessel Components§r

§3Submarine Dive Ballast Tank§r:
Regulates buoyancy to dive deep or surface rapidly.

§bAcoustic Sonar Radar§r:
Pings underwater hostile entities and submerged shipwrecks.
**Page 3:** §l§1Armament§r

§7Pressurized Torpedo Bolt§r (10 Dmg):
High-yield aquatic explosive projectile.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Submariner's Blueprint Manual** | `st:st_guidebook` | 1 | Shapeless: Book + Paper |
| **Submarine Dive Ballast** | `st:dive_ballast` | 16 | Pattern: `CCC / CFC / CCC` |
| **Acoustic Sonar Radar** | `st:sonar_radar` | 1 | Pattern: ` C  / PCP /  R ` |
| **Pressurized Torpedo Bolt** | `st:torpedo_bolt` | 64 | Pattern: ` I  / CTC /  F ` |
| **Reinforced Pressure Plate** | `st:pressure_hull_plate` | 64 | Pattern: `III / CCC / III` |
| **Abyssal Depth Gauge** | `st:sub_depth_gauge` | 1 | Pattern: ` G  / GCG /  G ` |
