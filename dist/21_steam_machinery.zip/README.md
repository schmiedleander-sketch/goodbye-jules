# Industrial Automation & Steam Machinery
> Minecraft Bedrock Edition (1.21.0+) Add-on

Steam boilers, high-pressure pipes, mechanical macerators, automated conveyor belts, and engineer wrenches.

## In-Game Guide Book
- **Title**: Industrial Steam Works
- **Author**: Chief Mechanist Vance
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Industrial Steam Works§r

Welcome to the age of mechanization!

Harness high-pressure steam boilers and mechanical gearboxes to process minerals, crush cobble into sand, and automate resource processing lines.
**Page 2:** §l§1Core Machinery§r

§cSteam Boiler Vessel§r:
Crafted with copper sheets, iron bars, and furnace core.

§6Mechanical Macerator§r:
Crushes raw ores into doubled refined powders.

§7Engineer's Adjusting Wrench§r:
Configures steam pipe throughput.
**Page 3:** §l§1Logistics & Power§r

§eConveyor Belt Assembly§r:
Transports items continuously across factory floors.

§8Pressure Pipe Conduit§r:
Channels pressurized steam between boilers and heavy machines.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Industrial Steam Works** | `sm:sm_guidebook` | 1 | Shapeless: Book + Paper |
| **Engineer's Adjusting Wrench** | `sm:engineer_wrench` | 1 | Pattern: ` I  /  II / S  ` |
| **Steam Boiler Core** | `sm:steam_boiler` | 64 | Pattern: `CCC / CFC / CCC` |
| **Mechanical Macerator** | `sm:mechanical_macerator` | 64 | Pattern: `IPI / IBI / IRI` |
| **Conveyor Belt Track** | `sm:conveyor_belt` | 64 | Pattern: `LLL / IRI / LLL` |
| **Reinforced Steam Pipe** | `sm:steam_pipe` | 64 | Pattern: `CCC /     / CCC` |
