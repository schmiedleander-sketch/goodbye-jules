# Backpacks & Pouches
> Minecraft Bedrock Edition (1.21.0+) Add-on

Expandable leather packs, miner satchels, and pocket ender pouches.

## In-Game Guide Book
- **Title**: Backpacker's Guide
- **Author**: Nomad Taylor
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Backpacks & Pouches§r

Organize inventory during long mining expeditions.

Craft handy pouches and heavy expedition packs to store tools and supplies on the go.
**Page 2:** §l§1Available Packs§r

§2Small Leather Pouch§r: 5 leather + string.
§6Traveler Backpack§r: Leather + iron + chest.
§bExpedition Backpack§r: Reinforced diamond frame.
§5Ender Pouch§r: Linked directly to ender chest storage.
**Page 3:** §l§1Miner's Satchel§r

Copper & iron lined satchel to carry raw ores and excavation tools.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Backpacker's Guide** | `bp:bp_guidebook` | 1 | Shapeless: Book + Paper |
| **Small Leather Pouch** | `bp:small_leather_pouch` | 1 | Pattern: ` L  / LSL / LLL` |
| **Traveler Backpack** | `bp:traveler_backpack` | 1 | Pattern: `LIL / LCL / LLL` |
| **Miner's Satchel** | `bp:miner_satchel` | 1 | Pattern: `ICI / LCL /  L ` |
| **Ender Pouch** | `bp:ender_pouch` | 1 | Pattern: ` E  / LCL /  L ` |
| **Expedition Backpack** | `bp:expedition_backpack` | 1 | Pattern: `DGD / LBL / DDD` |
