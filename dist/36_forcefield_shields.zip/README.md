# Energy Shields & Forcefield Emitters
> Minecraft Bedrock Edition (1.21.0+) Add-on

Forcefield emitter pylons, shield frequency modulators, energy deflector cells, and kinetic barriers.

## In-Game Guide Book
- **Title**: Forcefield Array Manual
- **Author**: Barrier Architect Maxwell
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§bEnergy Shields & Forcefields§r

Project luminous barrier envelopes to ward your base against creeper blast destruction and skeleton arrow volleys.
**Page 2:** §l§1Barrier Emitters§r

§bForcefield Pylon Emitter§r:
Generates an impenetrable spherical energy barrier.

§eShield Frequency Modulator§r:
Permits friendly allies to pass through active forcefield zones.
**Page 3:** §l§1Personal Deflectors§r

§aKinetic Barrier Aegis§r:
Portable shield deflecting high-velocity incoming projectiles.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Forcefield Array Manual** | `fs:fs_guidebook` | 1 | Shapeless: Book + Paper |
| **Forcefield Pylon Emitter** | `fs:forcefield_emitter` | 64 | Pattern: ` D  / IBI /  D ` |
| **Shield Frequency Modulator** | `fs:shield_modulator` | 1 | Pattern: ` R  / PAP /  R ` |
| **Kinetic Barrier Aegis** | `fs:kinetic_barrier` | 1 | Pattern: `DDD / DSD /  D ` |
| **Energy Flux Capacitor** | `fs:flux_capacitor` | 64 | Pattern: `RGR / GLG / RGR` |
| **Resonant Deflector Shard** | `fs:deflector_shard` | 64 | Pattern: ` P  / ADA /  P ` |
