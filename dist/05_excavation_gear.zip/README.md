# Excavation & Mining Gear
> Minecraft Bedrock Edition (1.21.0+) Add-on

Heavy 3x3 Mining Hammers, Excavator Trench Shovels, and Ore Magnets.

## In-Game Guide Book
- **Title**: Prospector's Handbook
- **Author**: Chief Digger Flint
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Excavation & Mining Gear§r

Tunnel through mountains rapidly with heavy excavation equipment.
**Page 2:** §l§1Tools§r

§7Iron Mining Hammer§r: Heavy vein carver.
§bDiamond Mining Hammer§r: Massive rock breaker.
§6Excavator Trench Shovel§r: Wide dirt clearing.
§cOre Magnet§r: Attracts mined drops directly to you.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Prospector's Handbook** | `eg:eg_guidebook` | 1 | Shapeless: Book + Paper |
| **Iron Mining Hammer** | `eg:iron_heavy_hammer` | 1 | Pattern: `III /  S  /  S ` |
| **Diamond Mining Hammer** | `eg:diamond_heavy_hammer` | 1 | Pattern: `DDD /  O  /  O ` |
| **Excavator Shovel** | `eg:excavator_shovel` | 1 | Pattern: ` I  / ISI /  S ` |
| **Prospector's Lens** | `eg:ore_prospector` | 1 | Pattern: ` C  / GAG /  C ` |
| **Lodestone Ore Magnet** | `eg:ore_magnet` | 1 | Pattern: `R R / I I /  L ` |
