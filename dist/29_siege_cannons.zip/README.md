# Siege Engineering & Cannons
> Minecraft Bedrock Edition (1.21.0+) Add-on

Heavy cast iron cannons, powder kegs, solid iron cannonballs, and mortar aiming quadrants.

## In-Game Guide Book
- **Title**: Siege Artillery Codex
- **Author**: Master Gunner Cromwell
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§8Siege Engineering & Cannons§r

Breach formidable stone fortifications and obliterate raiding waves with heavy artillery cannons.
**Page 2:** §l§1Artillery Parts§r

§8Cast Iron Cannon Barrel§r:
Thick-walled barrel forged to withstand massive gunpowder propellant explosions.

§cCompressed Powder Keg§r:
Triple-distilled propellant charge.
**Page 3:** §l§1Ammunition & Targeting§r

§7Solid Iron Cannonball§r:
Heavy spherical projectile causing massive impact cratering.

§eMortar Aiming Quadrant§r:
Calibrates firing trajectory.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Siege Artillery Codex** | `sc:sc_guidebook` | 1 | Shapeless: Book + Paper |
| **Cast Iron Cannon Barrel** | `sc:cannon_barrel` | 16 | Pattern: `III / I I / III` |
| **Solid Iron Cannonball** | `sc:cannonball` | 64 | Pattern: ` I  / III /  I ` |
| **Compressed Powder Keg** | `sc:powder_keg` | 16 | Pattern: `PPP / GTG / PPP` |
| **Mortar Aiming Quadrant** | `sc:aiming_quadrant` | 1 | Pattern: ` C  / CBC /  C ` |
| **Heavy Artillery Ramrod** | `sc:firing_ramrod` | 1 | Pattern: `  I /  S  / S  ` |
