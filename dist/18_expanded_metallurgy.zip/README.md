# Expanded Metallurgy
> Minecraft Bedrock Edition (1.21.0+) Add-on

Copper broadswords, amethyst blades, ruby gems, and steel battleaxes.

## In-Game Guide Book
- **Title**: Metallurgist's Guide
- **Author**: Master Founder Balthazar
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§eExpanded Metallurgy§r

Bridge mineral tiers with new weapon forgings and crystal blades.
**Page 2:** §l§1Metals & Gems§r

§6Copper Broadsword§r (5 Dmg): Early copper weapon.
§dAmethyst Blade§r (7 Dmg): Resonant crystal strike.
§4Blood Ruby & Battleaxe§r (9 Dmg): Scorching heavy axe.
§7Refined Steel Ingot§r: Smelted high-strength iron.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Metallurgist's Guide** | `em:em_guidebook` | 1 | Shapeless: Book + Paper |
| **Copper Broadsword** | `em:copper_broadsword` | 1 | Pattern: ` C  /  C  /  S ` |
| **Amethyst Crystalline Blade** | `em:amethyst_blade` | 1 | Pattern: ` A  /  A  /  G ` |
| **Blood Ruby** | `em:ruby_gem` | 64 | Pattern: ` R  / RDR /  R ` |
| **Ruby Battleaxe** | `em:ruby_battleaxe` | 1 | Pattern: `RR  / RS  /  S ` |
| **Refined Steel Ingot** | `em:steel_ingot` | 64 | Pattern: ` C  /  I  /  C ` |
