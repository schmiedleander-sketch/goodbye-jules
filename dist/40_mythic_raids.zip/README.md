# Mythological Boss Raids & Primordial Totems
> Minecraft Bedrock Edition (1.21.0+) Add-on

Titan summoning monoliths, primordial seals, demigod battleaxes, and divine champion aegis.

## In-Game Guide Book
- **Title**: Primordial Titan Lore
- **Author**: High Oracle Theodosius
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§4Mythological Boss Raids§r

Awaken slumbering ancient world titans through Primordial Monoliths to face legendary challenges for god-tier rewards.
**Page 2:** §l§1Summoning Monoliths§r

§4Titan Summoning Monolith§r:
Placed at ritual altars to summon primeval demigod raid encounters.

§6Primordial Binding Seal§r:
Golden rune locking cosmic titan spirits.
**Page 3:** §l§1Demigod Armaments§r

§cDemigod Cleaving Battleaxe§r (12 Dmg):
Forged from titan core fragments and netherite ingots.

§eDivine Champion Aegis§r:
Indestructible shield blessed by ancient deities.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Primordial Titan Lore** | `mr:mr_guidebook` | 1 | Shapeless: Book + Paper |
| **Titan Summoning Monolith** | `mr:titan_monolith` | 1 | Pattern: ` N  / DSD /  N ` |
| **Demigod Cleaving Battleaxe** | `mr:demigod_battleaxe` | 1 | Pattern: `NN  / NS  /  S ` |
| **Divine Champion Aegis** | `mr:divine_aegis` | 1 | Pattern: ` G  / GSG /  N ` |
| **Primordial Binding Seal** | `mr:primordial_seal` | 64 | Pattern: ` G  / ENE /  G ` |
| **Titan Relic Core Shard** | `mr:titan_core_shard` | 64 | Pattern: ` D  / DND /  D ` |
