# Ocean Diving & Harpoons
> Minecraft Bedrock Edition (1.21.0+) Add-on

Copper diving helmets, hydrodynamic fins, pressure harpoon guns, and abyssal lanterns.

## In-Game Guide Book
- **Title**: Abyssal Diver's Log
- **Author**: Captain Marina
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§3Ocean Diving & Harpoons§r

Submerge deep into ocean trenches and ancient underwater monuments.
**Page 2:** §l§1Diving Gear§r

§3Copper Diving Helmet§r: Extended underwater respiration.
§2Hydrodynamic Fins§r: Swift ocean swimming.
§7Pressure Harpoon Gun§r (8 Dmg): High velocity underwater shooter.
§bDeep Abyssal Lantern§r: Intense underwater lighting.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Abyssal Diver's Log** | `od:od_guidebook` | 1 | Shapeless: Book + Paper |
| **Copper Diving Helmet** | `od:diving_helmet` | 1 | Pattern: `CCC / CGC /  P ` |
| **Hydrodynamic Fins** | `od:diving_fins` | 1 | Pattern: `P P / L L / P P` |
| **Pressure Harpoon Gun** | `od:harpoon_gun` | 1 | Pattern: ` CI / PPC /   P` |
| **Barbed Harpoon Bolt** | `od:harpoon_bolt` | 64 | Pattern: ` I  /  C  /  F ` |
| **Deep Abyssal Lantern** | `od:abyssal_lantern` | 64 | Pattern: ` P  / PGP /  P ` |
