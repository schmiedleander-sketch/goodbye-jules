# Cooking Automata & Bakery Machinery
> Minecraft Bedrock Edition (1.21.0+) Add-on

Mechanical flour grain mills, industrial brick ovens, automatic churners, and artisan pastries.

## In-Game Guide Book
- **Title**: Automated Bakery Gazette
- **Author**: Master Baker Pierre
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Bakery Machinery§r

Revolutionize your kitchen with automated mills and high-throughput baking stations.
**Page 2:** §l§1Kitchen Machinery§r

§eMechanical Grain Mill§r:
Mills bundles of wheat into ultra-fine baking flour.

§cIndustrial Brick Oven§r:
Triple-speed baking for artisanal pastries, breads, and meat pies.
**Page 3:** §l§1Automated Churning§r

§6Automatic Butter Churner§r:
Processes bucket milk into sweet cream and butter pats.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Automated Bakery Gazette** | `bm:bm_guidebook` | 1 | Shapeless: Book + Paper |
| **Mechanical Grain Mill** | `bm:grain_mill` | 64 | Pattern: ` S  / IHI /  S ` |
| **Industrial Brick Oven** | `bm:industrial_oven` | 64 | Pattern: `BBB / BFB / BBB` |
| **Automatic Butter Churner** | `bm:butter_churner` | 64 | Pattern: ` P  / IBI /  P ` |
| **Artisan Cream Pastry** | `bm:artisan_pastry` | 16 | Pattern: ` S  / WEW /  B ` |
| **Wooden Baker's Paddle** | `bm:bakers_paddle` | 1 | Pattern: ` P  /  P  /  S ` |
