# Nether Relics & Forging
> Minecraft Bedrock Edition (1.21.0+) Add-on

Soulfire Greatswords, Magma Plated Shields, and Witherbane Talismans.

## In-Game Guide Book
- **Title**: Nether Smith's Black Tome
- **Author**: Pyromancer Malakor
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§4Nether Relics & Forging§r

Forge weapons from the scorching fires and soul sand of the Nether realm.
**Page 2:** §l§1Nether Equipment§r

§bSoulfire Greatsword§r (9 Dmg): Soulfire blade.
§cMagma Plated Shield§r: Heat resistant guard.
§8Witherbane Talisman§r: Wither warding charm.
§6Soulforged Ingot§r: High heat alloy.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Nether Smith's Black Tome** | `nr:nr_guidebook` | 1 | Shapeless: Book + Paper |
| **Soulfire Greatsword** | `nr:soulfire_blade` | 1 | Pattern: ` B  /  B  /  S ` |
| **Magma Plated Shield** | `nr:magma_shield` | 1 | Pattern: `MMM / MSM /  M ` |
| **Witherbane Talisman** | `nr:witherbane_talisman` | 1 | Pattern: ` N  / WSW /  N ` |
| **Soulforged Ingot** | `nr:soul_ingot` | 64 | Pattern: ` G  / SNS /  G ` |
| **Condensed Blaze Core** | `nr:blaze_core` | 64 | Pattern: `BBB / BFB / BBB` |
