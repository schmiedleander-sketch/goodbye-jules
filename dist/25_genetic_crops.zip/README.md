# Biome Botany & Genetic Crops
> Minecraft Bedrock Edition (1.21.0+) Add-on

Cross-pollination frames, DNA gene extractors, hybrid seed pods, and greenhouse nutrient soil.

## In-Game Guide Book
- **Title**: Botanist's Genetics Journal
- **Author**: Dr. Linnaeus Bloom
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§2Biome Botany & Genetics§r

Crossbreed agricultural specimens to discover mutated high-yield crops with supernatural properties.
**Page 2:** §l§1Lab Equipment§r

§aGene Extractor Chisel§r:
Extracts pure plant DNA alleles from wild flora.

§6Cross-Pollination Frame§r:
Aligns adjacent crop stems to trigger beneficial mutations.
**Page 3:** §l§1Supernatural Pods§r

§eGolden Hybrid Seed Pod§r:
Grows multi-harvest nutrient vegetables yielding bonus gold and saturation.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Botanist's Genetics Journal** | `gc:gc_guidebook` | 1 | Shapeless: Book + Paper |
| **Gene Extractor Chisel** | `gc:gene_extractor` | 1 | Pattern: `  I /  G  / S  ` |
| **Cross-Pollination Frame** | `gc:pollination_frame` | 64 | Pattern: `SSS / SHS / SSS` |
| **Hybrid Seed Pod** | `gc:hybrid_seed_pod` | 64 | Pattern: `PWP / WNW / PWP` |
| **Rich Nutrient Fertilizer** | `gc:nutrient_fertilizer` | 64 | Pattern: ` B  / RMR /  B ` |
| **Spectral Greenhouse Panel** | `gc:greenhouse_glass` | 64 | Pattern: ` G  / GLG /  G ` |
