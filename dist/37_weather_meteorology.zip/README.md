# Meteorology & Weather Systems
> Minecraft Bedrock Edition (1.21.0+) Add-on

Lightning accumulator rods, rain condensation totems, storm call horns, and atmospheric barometers.

## In-Game Guide Book
- **Title**: Meteorologist's Weather Atlas
- **Author**: Cloudweaver Zephyrus
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§3Meteorology & Weather§r

Read barometric trends and command storm systems to summon nourishing rainfall or harvest lightning power.
**Page 2:** §l§1Atmospheric Tools§r

§bBrass Precision Barometer§r:
Forecasts upcoming rain and thunderstorms.

§eLightning Accumulator Rod§r:
Stores raw electrical discharge during lightning strikes into reusable battery cells.
**Page 3:** §l§1Storm Calling§r

§fTempest Calling Horn§r:
Blasts resonant sound to summon cooling thunderstorm rains.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Meteorologist's Weather Atlas** | `wm:wm_guidebook` | 1 | Shapeless: Book + Paper |
| **Tempest Calling Horn** | `wm:storm_horn` | 1 | Pattern: ` C  /  G  /  C ` |
| **Brass Precision Barometer** | `wm:barometer_brass` | 1 | Pattern: ` C  / CGC /  C ` |
| **Lightning Accumulator Rod** | `wm:lightning_accumulator` | 64 | Pattern: ` L  / LCL /  L ` |
| **Cloud Condenser Vessel** | `wm:cloud_condenser` | 64 | Pattern: ` P  / PBP /  P ` |
| **Charged Storm Crystal** | `wm:storm_crystal` | 64 | Pattern: ` A  / DLD /  A ` |
