# Pet Care & Taming
> Minecraft Bedrock Edition (1.21.0+) Add-on

Training whistles, armored pet collars, dog biscuits, and traveler pet carriers.

## In-Game Guide Book
- **Title**: Master Pet Care Guide
- **Author**: Beastmaster Kael
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§aPet Care & Taming§r

Equip and protect your animal companions with specialized veterinary and taming tools.
**Page 2:** §l§1Pet Gear§r

§6Training Whistle§r: Direct tamed wolves and cats.
§cArmored Collar§r: Leather and iron defense collar.
§ePet Vitality Biscuit§r: Nutritious healing snack.
§6Traveler Pet Carrier§r: Portable cage to move pets safely.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Master Pet Care Guide** | `pc:pc_guidebook` | 1 | Shapeless: Book + Paper |
| **Silver Training Whistle** | `pc:training_whistle` | 1 | Pattern: ` I  /  I  /    ` |
| **Armored Pet Collar** | `pc:armored_collar` | 1 | Pattern: ` L  / LIL /  L ` |
| **Pet Vitality Biscuit** | `pc:vitality_biscuit` | 64 | Pattern: ` W  / BMB /  W ` |
| **Traveler Pet Carrier** | `pc:pet_carrier` | 1 | Pattern: ` B  / LCL /  L ` |
| **Soft Grooming Brush** | `pc:brush_grooming` | 1 | Pattern: ` F  /  S  /  S ` |
