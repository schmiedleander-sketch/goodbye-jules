# Archaeology & Fossil Reconstruction
> Minecraft Bedrock Edition (1.21.0+) Add-on

Sifting sieve tables, fossil cleaning solvents, amber extractors, and ancient dinosaur skeleton displays.

## In-Game Guide Book
- **Title**: Archaeologist's Field Journal
- **Author**: Professor Indiana Bones
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Archaeology & Fossils§r

Excavate primeval fossils buried beneath desert sands and gravel beds to reconstruct prehistoric specimens.
**Page 2:** §l§1Excavation Equipment§r

§eArcheological Sieve Table§r:
Sifts gravel and suspicious sand to uncover rare fossil bones and amber nuggets.

§7Fossil Cleaning Solvent§r:
Cleans hardened bedrock sediment off fossil fragments.
**Page 3:** §l§1Relics of the Past§r

§6Amber Fossil Core§r:
Contains ancient genetic sequences.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Archaeologist's Field Journal** | `af2:af2_guidebook` | 1 | Shapeless: Book + Paper |
| **Archaeological Sieve Table** | `af2:sieve_table` | 64 | Pattern: ` S  / PBP /  P ` |
| **Fossil Cleaning Solvent** | `af2:cleaning_solvent` | 16 | Pattern: ` S  /  W  /  B ` |
| **Amber Fossil Core** | `af2:amber_core` | 64 | Pattern: ` H  / HEH /  H ` |
| **Fine Excavation Brush** | `af2:fossil_brush_fine` | 1 | Pattern: ` F  /  C  /  S ` |
| **Prehistoric Skull Relic** | `af2:dino_skull_relic` | 16 | Pattern: `BBB / B B / BBB` |
