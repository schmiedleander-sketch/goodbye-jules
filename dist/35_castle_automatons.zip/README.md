# Castle Defense Automatons & Golems
> Minecraft Bedrock Edition (1.21.0+) Add-on

Brass sentry turret cores, automaton command wands, clockwork golem hearts, and repair wrenches.

## In-Game Guide Book
- **Title**: Automaton Sentry Blueprints
- **Author**: Grand Clockmaker Daedalus
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Castle Automatons§r

Build autonomous brass sentries to guard fortress gates and castle walls against nighttime siege raids.
**Page 2:** §l§1Mechanical Guardians§r

§eClockwork Golem Heart§r:
Mechanical core that breathes life into iron and brass automaton frames.

§6Brass Sentry Turret Core§r:
Stationary turret unit that targets approaching hostile mobs.
**Page 3:** §l§1Command & Maintenance§r

§7Automaton Command Baton§r:
Directs automaton guards to patrol, guard, or follow.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Automaton Sentry Blueprints** | `ca2:ca2_guidebook` | 1 | Shapeless: Book + Paper |
| **Clockwork Golem Heart** | `ca2:golem_heart` | 64 | Pattern: ` C  / RIR /  C ` |
| **Brass Sentry Turret Core** | `ca2:sentry_core` | 64 | Pattern: ` I  / CDC /  I ` |
| **Automaton Command Baton** | `ca2:command_baton` | 1 | Pattern: `  G /  S  / S  ` |
| **Automaton Repair Tool** | `ca2:repair_kit` | 1 | Pattern: ` I  / SIS /  I ` |
| **Heavy Brass Cogwheel** | `ca2:brass_gear` | 64 | Pattern: ` C  / CIC /  C ` |
