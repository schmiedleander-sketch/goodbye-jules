# Dimensional Portals & Rift Anchors
> Minecraft Bedrock Edition (1.21.0+) Add-on

Rift stabilizers, dimensional anchors, void dials, and phased inter-realm compasses.

## In-Game Guide Book
- **Title**: Interdimensional Rift Annals
- **Author**: Voidstrider Chronos
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§5Dimensional Rifts§r

Tear and tether stable wormholes across the Nether, Overworld, and End without building bulky obsidian frames.
**Page 2:** §l§1Anchoring Apparatus§r

§dPhased Dimensional Anchor§r:
Locks your coordinates across spatial dimensions.

§bSpatial Void Dial§r:
Displays temporal rift stability in current realm.
**Page 3:** §l§1Rift Technology§r

§eRift Stabilizer Core§r:
Prevents dimensional backlash when leaping through unstable portals.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Interdimensional Rift Annals** | `dr:dr_guidebook` | 1 | Shapeless: Book + Paper |
| **Phased Dimensional Anchor** | `dr:dimensional_anchor` | 1 | Pattern: ` C  / ORO /  C ` |
| **Spatial Void Dial** | `dr:void_dial` | 1 | Pattern: ` G  / ECE /  G ` |
| **Rift Stabilizer Core** | `dr:rift_stabilizer` | 64 | Pattern: ` A  / EDE /  A ` |
| **Inter-Realm Phased Compass** | `dr:phased_compass` | 1 | Pattern: ` E  / LCL /  E ` |
| **Warp Resonator** | `dr:warp_resonator` | 64 | Pattern: ` P  / RER /  P ` |
