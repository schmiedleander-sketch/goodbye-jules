# Biochemical Alchemy & Mutation Serums
> Minecraft Bedrock Edition (1.21.0+) Add-on

Centrifuge alembics, gene mutagen catalysts, beast mutation serums, and hazmat gas masks.

## In-Game Guide Book
- **Title**: Mutagen Lab Records
- **Author**: Dr. Frankenstein Jekyll
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§aBiochemical Alchemy§r

Synthesize unstable biological serums to temporarily supercharge player attributes like jump height, strike power, and resistance.
**Page 2:** §l§1Lab Apparatus§r

§2Centrifuge Alembic§r:
Separates organic cellular fluids into concentrated reagents.

§aBeast Mutation Serum§r:
Grants supernatural strength and resistance at the cost of intense hunger.
**Page 3:** §l§1Safety Gear§r

§eHazmat Bio-Respirator Mask§r:
Wards against poisonous fumes and chemical gases.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Mutagen Lab Records** | `bs:bs_guidebook` | 1 | Shapeless: Book + Paper |
| **Centrifuge Alembic** | `bs:centrifuge_alembic` | 64 | Pattern: ` G  / IBI /  I ` |
| **Beast Mutation Serum** | `bs:mutation_serum` | 16 | Pattern: ` S  / EBE /  S ` |
| **Hazmat Bio-Respirator** | `bs:hazmat_mask` | 1 | Pattern: ` L  / LGL /  C ` |
| **Gene Mutagen Catalyst** | `bs:bio_catalyst` | 64 | Pattern: ` R  / GNG /  R ` |
| **Universal Antidote Vial** | `bs:antidote_vial` | 16 | Pattern: ` H  /  M  /  B ` |
