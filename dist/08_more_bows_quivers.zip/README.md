# More Bows & Quivers
> Minecraft Bedrock Edition (1.21.0+) Add-on

Explosive blast bows, viper poison shortbows, reinforced longbows, and quivers.

## In-Game Guide Book
- **Title**: Archer's Field Journal
- **Author**: Ranger Hawkeye
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§2More Bows & Quivers§r

Upgrade your marksmanship with specialized bows for long-range dominance.
**Page 2:** §l§1Bows & Ammo§r

§cBlast Bow§r: Shoots explosive volleys.
§2Viper Shortbow§r: Poison arrows.
§7Reinforced Longbow§r: High durability iron bow.
§6Hunter's Quiver§r: Arrow ammunition pack.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Archer's Field Journal** | `mb:mb_guidebook` | 1 | Shapeless: Book + Paper |
| **Reinforced Longbow** | `mb:reinforced_bow` | 1 | Pattern: ` IS / I S /  IS` |
| **Blast Bow** | `mb:explosive_bow` | 1 | Pattern: `TBS / T S / TBS` |
| **Viper Shortbow** | `mb:poison_shortbow` | 1 | Pattern: ` PS / F S /  PS` |
| **Hunter's Quiver** | `mb:archer_quiver` | 1 | Pattern: ` L  / LAL /  L ` |
| **Barbed Broadhead Arrow** | `mb:barbed_arrow` | 64 | Pattern: ` I  /  S  /  F ` |
