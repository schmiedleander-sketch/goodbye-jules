# Wilderness Survival & Thermal Insulation
> Minecraft Bedrock Edition (1.21.0+) Add-on

Thermoregulating insulated tunics, chemical heat packs, glacial cooling pouches, and ceramic water purifiers.

## In-Game Guide Book
- **Title**: Extreme Climates Guide
- **Author**: Alpine Scout Nanook
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§cThermal Insulation & Survival§r

Survive sub-zero blizzards in frozen peaks and blistering heatwaves in volcanic basalt deltas.
**Page 2:** §l§1Thermal Insulation§r

§cChemical Heat Pack§r:
Keeps your core temperature warm during freezing blizzard conditions.

§bGlacial Cooling Pouch§r:
Wards against heat exhaustion in blazing Nether landscapes.
**Page 3:** §l§1Purification§r

§eCeramic Water Purifier§r:
Filters swamp and river water into clean potable drinking hydration.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Extreme Climates Guide** | `ti:ti_guidebook` | 1 | Shapeless: Book + Paper |
| **Thermoregulated Parka** | `ti:insulated_tunic` | 1 | Pattern: `L L / LWL / LLL` |
| **Chemical Heat Pack** | `ti:heat_pack` | 16 | Pattern: ` I  / CMC /  I ` |
| **Glacial Cooling Pouch** | `ti:cooling_pouch` | 16 | Pattern: ` S  / LIL /  S ` |
| **Ceramic Water Purifier** | `ti:water_purifier` | 1 | Pattern: ` C  / SGS /  C ` |
| **Woolen Thermal Lining** | `ti:thermal_lining` | 64 | Pattern: `WWW / SSS / WWW` |
