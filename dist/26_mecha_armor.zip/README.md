# Advanced Mecha Armor & Exoskeletons
> Minecraft Bedrock Edition (1.21.0+) Add-on

Hydraulic powered exoskeleton frames, servo cores, jet jump thrusters, and shock absorbers.

## In-Game Guide Book
- **Title**: Cybernetic Rig Manual
- **Author**: Master Armorer Vulcan
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§7Mecha Exoskeletons§r

Transform standard survival armor into powered heavy mechanical rigs capable of deflecting massive blows.
**Page 2:** §l§1Exoskeleton Parts§r

§bPowered Exoskeleton Frame§r:
Steel chassis equipped with hydraulic servos and kinetic battery dampeners.

§eHydraulic Jet Thruster§r:
Mounts to legs to provide high-altitude escape boosts.
**Page 3:** §l§1Power Supply§r

§cHigh Density Energy Cell§r:
Powers automated shielding and kinetic recoil springs.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Cybernetic Rig Manual** | `ma:ma_guidebook` | 1 | Shapeless: Book + Paper |
| **Exoskeleton Chassis Frame** | `ma:exoskeleton_frame` | 1 | Pattern: `I I / ICI / IPI` |
| **Hydraulic Jet Thruster** | `ma:jet_thruster` | 1 | Pattern: ` F  / RCR /  F ` |
| **Heavy Hydraulic Servo** | `ma:hydraulic_servo` | 64 | Pattern: ` I  / CPC /  I ` |
| **Dense Energy Cell** | `ma:energy_cell` | 64 | Pattern: `RGR / GLG / RGR` |
| **Kinetic Shock Absorber** | `ma:shock_absorber` | 1 | Pattern: ` S  / LPL /  S ` |
