# Waystones & Teleport Scrolls
> Minecraft Bedrock Edition (1.21.0+) Add-on

Fast recall scrolls, warp gems, and tablets of return for instant transport.

## In-Game Guide Book
- **Title**: Warp Master's Tome
- **Author**: Archmage Varis
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§5Waystones & Scrolls§r

Instantaneous travel across biomes!

Inscribe teleportation runes onto enchanted parchment to leap across dimensions.
**Page 2:** §l§1Scrolls & Items§r

§bHome Recall Scroll§r: Lapis lazuli + paper + gold nugget.
§eCave Escape Scroll§r: Feather + paper + redstone.
§5Bound Warp Stone§r: Infused with Ender pearl essence.
§dTablet of Return§r: Obsidian and diamond reinforced rune.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Warp Master's Tome** | `ws:ws_guidebook` | 1 | Shapeless: Book + Paper |
| **Recall Scroll** | `ws:recall_scroll` | 16 | Pattern: ` L  / PPP /  G ` |
| **Bound Warp Stone** | `ws:warp_stone` | 16 | Pattern: ` D  / PEP /  D ` |
| **Escape Scroll** | `ws:cave_escape_scroll` | 16 | Pattern: ` F  / PPP /  R ` |
| **Rift Shard** | `ws:rift_shard` | 64 | Pattern: ` A  / EPE /  A ` |
| **Tablet of Return** | `ws:teleport_tablet` | 1 | Pattern: `ODO / DRD / ODO` |
