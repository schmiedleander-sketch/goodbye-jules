# Deep Dark Catacombs & Warden Relics
> Minecraft Bedrock Edition (1.21.0+) Add-on

Sculk resonance chimes, sonic boom staves, soul cages, and stealth shadowcloaks.

## In-Game Guide Book
- **Title**: Sculk Resonance Tome
- **Author**: Deep Hollow Chronicler
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§3Warden Relics & Sculk§r

Extract sonic vibrations from deep dark ancient cities to weaponize acoustic resonance against all who oppose you.
**Page 2:** §l§1Acoustic Relics§r

§3Sonic Boom Staff§r (10 Dmg):
Channels concentrated sonic pulses across long distances bypassing standard armor.

§bSculk Resonance Chime§r:
Emits frequencies that distract hostiles and detect hidden cave passages.
**Page 3:** §l§1Stealth Cloaks§r

§8Shadowcloak Mantle§r:
Nullifies footstep vibrations, allowing silent movement.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Sculk Resonance Tome** | `wr:wr_guidebook` | 1 | Shapeless: Book + Paper |
| **Sonic Boom Staff** | `wr:sonic_staff` | 1 | Pattern: ` E  /  S  /  S ` |
| **Sculk Resonance Chime** | `wr:sculk_chime` | 1 | Pattern: ` A  / AEA /  S ` |
| **Shadowcloak Mantle** | `wr:shadowcloak` | 1 | Pattern: `SES / SLS /  S ` |
| **Resonant Soul Cage** | `wr:soul_cage` | 64 | Pattern: `IBI / BSB / IBI` |
| **Hardened Sculk Tendril** | `wr:sculk_tendril` | 64 | Pattern: ` S  / SES /  S ` |
