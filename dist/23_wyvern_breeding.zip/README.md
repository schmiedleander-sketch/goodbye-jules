# Dragon Kin & Wyvern Breeding
> Minecraft Bedrock Edition (1.21.0+) Add-on

Nesting incubators, dragon call whistles, wyvern saddles, and bottled dragon breath treats.

## In-Game Guide Book
- **Title**: Wyvern Breeder's Handbook
- **Author**: Dragonlord Ignis
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§dWyvern Breeding§r

Domesticate descendants of the great Ender Dragon! Hatch ancient eggs, care for wyvern hatchlings, and ride the skies.
**Page 2:** §l§1Hatching & Care§r

§5Nesting Incubator Core§r:
Provides constant thermal incubation for dragon and wyvern clutches.

§eDragon Call Whistle§r:
Commands flying mounts to hover, dive, or land safely.
**Page 3:** §l§1Riding Equipment§r

§6Reinforced Wyvern Saddle§r:
Cushioned with diamond studs and netherite clasps for supersonic aerial maneuvering.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Wyvern Breeder's Handbook** | `wb:wb_guidebook` | 1 | Shapeless: Book + Paper |
| **Dragon Call Whistle** | `wb:wyvern_whistle` | 1 | Pattern: ` G  /  B  /    ` |
| **Nesting Incubator Core** | `wb:incubator_core` | 64 | Pattern: `HHH / HBH / HHH` |
| **Reinforced Wyvern Saddle** | `wb:wyvern_saddle` | 1 | Pattern: `LDL / LSL /    ` |
| **Draconic Vitality Treat** | `wb:dragon_treat` | 64 | Pattern: ` D  / GBG /  D ` |
| **Hardened Wyvern Scale** | `wb:wyvern_scale` | 64 | Pattern: ` O  / ODO /  O ` |
