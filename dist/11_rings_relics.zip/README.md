# Enchanted Rings & Relics
> Minecraft Bedrock Edition (1.21.0+) Add-on

Magical bands of swiftness, regeneration, fireguard amulets, and night vision spectacles.

## In-Game Guide Book
- **Title**: Jeweler's Reliquary
- **Author**: Grand Lapidary Aurelius
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Enchanted Rings & Relics§r

Channel passive blessings through enchanted jewelry forged with gold and jewels.
**Page 2:** §l§1Relics§r

§bRing of Swiftness§r: Gold + lapis lazuli.
§aRing of Vitality§r: Gold + emerald.
§cFireguard Talisman§r: Chains + magma cream.
§dNight Sight Spectacles§r: Copper + amethyst.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Jeweler's Reliquary** | `rr:rr_guidebook` | 1 | Shapeless: Book + Paper |
| **Ring of Swiftness** | `rr:ring_swiftness` | 1 | Pattern: ` G  / G L /  G ` |
| **Ring of Vitality** | `rr:ring_vitality` | 1 | Pattern: ` G  / G E /  G ` |
| **Fireguard Talisman** | `rr:fireguard_talisman` | 1 | Pattern: ` C  / CMC /  C ` |
| **Night Sight Spectacles** | `rr:night_spectacles` | 1 | Pattern: `C C / AGA /    ` |
| **Blank Jeweled Band** | `rr:jeweled_band` | 16 | Pattern: ` G  / G G /  G ` |
