# Crops & Cooking
> Minecraft Bedrock Edition (1.21.0+) Add-on

Sweet strawberries, golden corn, ripe tomatoes, chef knives, and sandwiches.

## In-Game Guide Book
- **Title**: Master Chef's Culinary
- **Author**: Chef Remy Green
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§2Crops & Cooking§r

Cultivate new gourmet crops and prepare wholesome sandwiches.
**Page 2:** §l§1Produce§r

§cSweet Strawberry§r: Quick berry snack.
§eGolden Corn§r: Crunchy ears of grain.
§4Ripe Tomato§r: Juicy salad ingredient.
§7Chef's Knife§r: Food preparation tool.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Master Chef's Culinary** | `cc:cc_guidebook` | 1 | Shapeless: Book + Paper |
| **Sweet Strawberry** | `cc:strawberry` | 64 | Pattern: ` S  /  B  /  S ` |
| **Golden Corn** | `cc:corn_cob` | 64 | Pattern: ` W  /  Y  /  W ` |
| **Ripe Tomato** | `cc:tomato` | 64 | Pattern: ` A  /  R  /  S ` |
| **Chef's Knife** | `cc:chef_knife` | 1 | Pattern: `  I /  I  / S  ` |
| **Gourmet Sandwich** | `cc:gourmet_sandwich` | 16 | Pattern: ` B  / TPC /  B ` |
