# Arcane Infusion & Runecrafting
> Minecraft Bedrock Edition (1.21.0+) Add-on

Pedestal infusion altars, runic carving chisels, bound spell glyphs, and elemental matrices.

## In-Game Guide Book
- **Title**: Arcane Infusion Grimoire
- **Author**: Runemaster Eldrin
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§5Arcane Infusion§r

Channel latent planetary leyline currents into mundane stone pedestals to infuse items with divine enchantments.
**Page 2:** §l§1The Infusion Altar§r

§dInfusion Altar Pedestal§r:
Constructed from polished deepslate and lapis lazuli. Forms the centerpiece for ritual item binding.

§bDiamond Runic Chisel§r:
Carves sacred inscriptions onto blank tablets.
**Page 3:** §l§1Glyphs & Matrices§r

§6Solar Infusion Glyph§r: Light and radiance ward.
§3Abyssal Runestone Matrix§r: Focuses tide powers.
§aPrimal Mana Matrix§r: Universal spellcraft catalyst.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Arcane Infusion Grimoire** | `ai:ai_guidebook` | 1 | Shapeless: Book + Paper |
| **Runic Carving Chisel** | `ai:runic_chisel` | 1 | Pattern: `  D /  S  / S  ` |
| **Infusion Altar Pedestal** | `ai:infusion_pedestal` | 64 | Pattern: `LPL /  D  / DDD` |
| **Solar Infusion Glyph** | `ai:solar_glyph` | 64 | Pattern: ` G  / GAG /  G ` |
| **Primal Mana Matrix** | `ai:mana_matrix` | 64 | Pattern: `EDE / DAD / EDE` |
| **Blank Runestone Tablet** | `ai:blank_runestone` | 64 | Pattern: ` D  / DSD /  D ` |
