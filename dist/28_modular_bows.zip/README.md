# Modular Bows & Ballistics
> Minecraft Bedrock Edition (1.21.0+) Add-on

Ergonomic composite grips, flexible limbs, optic sights, and heavy ballistic bolts.

## In-Game Guide Book
- **Title**: Ballistic Engineer's Field Guide
- **Author**: Marksman Vance
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§6Modular Bows & Ballistics§r

Standard recurve bows cannot compare with customizable modular archery chassis engineered for precision.
**Page 2:** §l§1Bow Modules§r

§6Composite Ergonomic Grip§r:
Improves steady aim under harsh conditions.

§eOptic Scope Sight§r:
Amethyst magnifying lens for pinpoint headshots.
**Page 3:** §l§1Modular Chassis§r

§7Ballistic Compound Frame§r (9 Dmg):
Delivers hyper-velocity broadheads over extreme ranges.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Ballistic Engineer's Field Guide** | `mo:mo_guidebook` | 1 | Shapeless: Book + Paper |
| **Ballistic Compound Frame** | `mo:compound_frame` | 1 | Pattern: ` GS / C S /  GS` |
| **Composite Ergonomic Grip** | `mo:composite_grip` | 64 | Pattern: ` L  / ILI /  L ` |
| **Optic Scope Sight** | `mo:optic_sight` | 1 | Pattern: ` C  / GAG /  C ` |
| **Heavy Ballistic Bolt** | `mo:ballistic_bolt` | 64 | Pattern: ` I  /  C  /  F ` |
| **High Tension Bowstring** | `mo:tension_cable` | 64 | Pattern: `SSS / SCS / SSS` |
