# Alchemical Flasks & Bombs
> Minecraft Bedrock Edition (1.21.0+) Add-on

Incendiary fire flasks, dense smoke bombs, glacial frost vials, and elixirs.

## In-Game Guide Book
- **Title**: Alchemist's Formulae
- **Author**: Grand Chemist Paracelsus
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§eAlchemical Flasks & Bombs§r

Turn brewing materials into thrown explosive flasks and combat concoctions.
**Page 2:** §l§1Concoctions§r

§cFire Flask§r: Blazes impact zones.
§8Smoke Bomb§r: Obscuring fog screen.
§bFrost Vial§r: Chilling flash-freeze.
§aHealing Elixir§r: Concentrated instant potion.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Alchemist's Formulae** | `af:af_guidebook` | 1 | Shapeless: Book + Paper |
| **Incendiary Fire Flask** | `af:fire_flask` | 16 | Pattern: ` G  / GFG /  G ` |
| **Dense Smoke Bomb** | `af:smoke_bomb` | 16 | Pattern: ` C  / PGP /  C ` |
| **Glacial Frost Vial** | `af:frost_vial` | 16 | Pattern: ` I  / PBP /  I ` |
| **Concentrated Healing Elixir** | `af:healing_elixir` | 16 | Pattern: ` G  / MTM /  B ` |
| **Alchemical Catalyst Residue** | `af:alchemical_residue` | 64 | Pattern: ` R  / GSG /  R ` |
