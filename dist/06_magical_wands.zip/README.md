# Magical Wands & Spells
> Minecraft Bedrock Edition (1.21.0+) Add-on

Arcane pyromancy wands, frostbite beams, and healing scepters.

## In-Game Guide Book
- **Title**: Compendium of Sorcery
- **Author**: Archmage Cynthia
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§dMagical Wands & Spells§r

Harness mystical spellcasting with staves carved from arcane crystals.
**Page 2:** §l§1Wands§r

§cWand of Pyromancy§r: Bursts of fire charges.
§bWand of Cryomancy§r: Freezing ice shards.
§aRestorative Scepter§r: Channels healing energy.
§dApprentice Wand§r: Starter casting focus.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Compendium of Sorcery** | `mw:mw_guidebook` | 1 | Shapeless: Book + Paper |
| **Apprentice Wand** | `mw:wand_apprentice` | 1 | Pattern: ` A  /  S  /  S ` |
| **Wand of Pyromancy** | `mw:wand_pyromancy` | 1 | Pattern: ` F  /  B  /  B ` |
| **Wand of Cryomancy** | `mw:wand_cryomancy` | 1 | Pattern: ` P  /  B  /  S ` |
| **Restorative Scepter** | `mw:healing_scepter` | 1 | Pattern: ` G  /  T  /  S ` |
| **Pure Mana Crystal** | `mw:mana_crystal` | 64 | Pattern: ` A  / DED /  A ` |
