# Necromancy & Soul Binding
> Minecraft Bedrock Edition (1.21.0+) Add-on

Soul phylacteries, necromancer summoning staves, resurrection ritual chalk, and bone effigies.

## In-Game Guide Book
- **Title**: Necromantic Rituals
- **Author**: Lich Lord Mortis
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§2Necromancy & Soul Binding§r

Command dark powers of the veil to reanimate skeletal defenders and store spirit life-force in crystalline vessels.
**Page 2:** §l§1Artifacts of the Veil§r

§aBone Minion Summoning Staff§r (8 Dmg):
Raises friendly skeleton guardians to fight beside you.

§2Soul Phylactery Vessel§r:
Harvests soul energy upon defeating undead.
**Page 3:** §l§1Rituals§r

§fResurrection Ritual Chalk§r:
Draws ritual circles to bind lingering souls.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Necromantic Rituals** | `ns:ns_guidebook` | 1 | Shapeless: Book + Paper |
| **Bone Summoning Staff** | `ns:necromancer_staff` | 1 | Pattern: ` B  /  S  /  S ` |
| **Soul Phylactery Vessel** | `ns:soul_phylactery` | 1 | Pattern: ` G  / GDG /  G ` |
| **Resurrection Ritual Chalk** | `ns:ritual_chalk` | 16 | Pattern: ` B  /  C  /  B ` |
| **Protective Bone Effigy** | `ns:bone_effigy` | 16 | Pattern: ` B  / BSB /  B ` |
| **Essence of Decay** | `ns:essence_of_decay` | 64 | Pattern: ` R  / FSF /  R ` |
