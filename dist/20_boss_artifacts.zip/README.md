# Boss Artifacts & Totems
> Minecraft Bedrock Edition (1.21.0+) Add-on

Dragon relic cores, totems of undying wrath, berserker blood charms, and void pendants.

## In-Game Guide Book
- **Title**: Ancient Relic Mythos
- **Author**: High Scholar Ozymandias
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§5Boss Artifacts & Totems§r

Assemble legendary relics from the remnants of slain world sovereigns.
**Page 2:** §l§1Legendary Artifacts§r

§5Dragon Relic Core§r: Ender Dragon core energy.
§4Totem of Undying Wrath§r: Nether Star infused survival totem.
§cBerserker Blood Charm§r: Critical hit amplifier.
§bVoid Defiance Pendant§r: Spatial resistance ward.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Ancient Relic Mythos** | `ba:ba_guidebook` | 1 | Shapeless: Book + Paper |
| **Dragon Relic Core** | `ba:dragon_relic_core` | 1 | Pattern: ` E  / DBD /  E ` |
| **Totem of Undying Wrath** | `ba:totem_of_wrath` | 1 | Pattern: ` G  / TST /  G ` |
| **Berserker Blood Charm** | `ba:berserker_charm` | 1 | Pattern: ` R  / RNR /  R ` |
| **Void Defiance Pendant** | `ba:void_pendant` | 1 | Pattern: ` C  / OEO /  C ` |
| **Ancient Relic Fragment** | `ba:ancient_relic_fragment` | 64 | Pattern: ` N  /  E  /  N ` |
