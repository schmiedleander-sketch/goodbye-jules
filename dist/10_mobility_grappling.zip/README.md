# Mobility & Grappling
> Minecraft Bedrock Edition (1.21.0+) Add-on

Grappling hooks, dash feathers, spring jump boots, and silk glider capes.

## In-Game Guide Book
- **Title**: Acrobat's Field Manual
- **Author**: Skystrider Zephyr
- **Spawn Behavior**: Players receive this guidebook upon entering the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§bMobility & Grappling§r

Conquer steep mountain cliffs and deep ravines with dynamic parkour traversal gear.
**Page 2:** §l§1Movement Gear§r

§7Grappling Hook§r: Braided cable climbing tool.
§eDash Feather§r: Forward burst of speed.
§aSpring Jump Boots§r: Enhanced vertical jumps.
§fSilk Glider Cape§r: Gentle descent glider.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Acrobat's Field Manual** | `mg:mg_guidebook` | 1 | Shapeless: Book + Paper |
| **Grappling Hook** | `mg:grappling_hook` | 1 | Pattern: `  I /  S  / C  ` |
| **Dash Feather** | `mg:dash_feather` | 1 | Pattern: ` F  / GBG /  F ` |
| **Bouncy Spring Boots** | `mg:spring_boots` | 1 | Pattern: `L L / S S / P P` |
| **Silk Glider Cape** | `mg:glider_cape` | 1 | Pattern: `BBB / SSS /  S ` |
| **Kinetic Coil** | `mg:kinetic_coil` | 64 | Pattern: ` I  / RCR /  I ` |
