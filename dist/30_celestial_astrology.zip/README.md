# Celestial Astrology & Moon Magic
> Minecraft Bedrock Edition (1.21.0+) Add-on

Star observatory lenses, celestial constellation charts, lunar talismans, and starlight crystals.

## In-Game Guide Book
- **Title**: Celestial Starlight Almanac
- **Author**: Astrologer Cassiopeia
- **Spawn Behavior**: Players receive this guidebook automatically upon joining the world, and can recraft it anytime using Book + Paper.

### Guidebook Pages
**Page 1:** §l§9Celestial Astrology§r

Attune to the cosmic dance of the sun, moon, and stars to empower mystical lunar talismans.
**Page 2:** §l§1Stargazing Instruments§r

§bObservatory Starlight Lens§r:
Focuses moonlight rays onto astrological altars.

§eCelestial Star Chart§r:
Parchment documenting planetary alignments for night blessings.
**Page 3:** §l§1Cosmic Talismans§r

§dLunar Phases Talisman§r:
Grants night sight and high jumping under open starry skies.

## Items & Equipment
| Item Name | Identifier | Max Stack | Crafting Recipe |
| :--- | :--- | :--- | :--- |
| **Celestial Starlight Almanac** | `ca:ca_guidebook` | 1 | Shapeless: Book + Paper |
| **Observatory Starlight Lens** | `ca:observatory_lens` | 1 | Pattern: ` G  / GAG /  G ` |
| **Celestial Star Chart** | `ca:star_chart` | 16 | Pattern: ` L  / PPP /  G ` |
| **Lunar Phases Talisman** | `ca:lunar_talisman` | 1 | Pattern: ` C  / QMQ /  C ` |
| **Condensed Starlight Crystal** | `ca:starlight_crystal` | 64 | Pattern: ` D  / GAG /  D ` |
| **Brass Astrolabe** | `ca:astrolabe` | 1 | Pattern: ` C  / CGC /  C ` |
